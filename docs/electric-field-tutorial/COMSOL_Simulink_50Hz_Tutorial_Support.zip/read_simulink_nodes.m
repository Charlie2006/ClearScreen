% Input: five Timeseries objects N0_log ... N4_log from Simulink To Workspace.
% If logs are in a SimulationOutput object 'out', first assign e.g.
% N0_log=out.N0_log; ... N4_log=out.N4_log;
logs={N0_log,N1_log,N2_log,N3_log,N4_log};
f0=50; w=2*pi*f0;
Vhat=zeros(5,1); dc=zeros(5,1);
for k=1:5
    t=logs{k}.Time(:); v=squeeze(logs{k}.Data); v=v(:);
    assert(numel(t)==numel(v),'Expected scalar Timeseries data.');
    mask=t>=t(end)-0.2;
    assert(nnz(mask)>=20,'Not enough samples in final 0.2 s.');
    A=[sin(w*t(mask)),cos(w*t(mask)),ones(nnz(mask),1)];
    coefficients=A\v(mask);
    Vhat(k)=(coefficients(1)+1i*coefficients(2))/sqrt(2);
    dc(k)=coefficients(3);
end
Vhat=Vhat*exp(-1i*angle(Vhat(1))); % phase reference: HV input
node_names=["n0";"n1";"n2";"n3";"n4"];
node_table=table(node_names,real(Vhat),imag(Vhat),abs(Vhat),angle(Vhat)*180/pi,dc,...
    'VariableNames',{'Node','Real_V','Imag_V','RMS_V','Phase_deg','DC_offset_V'});
disp(node_table);
H=Vhat(5)/Vhat(1);
fprintf('H magnitude=%.10g; phase=%.8f deg\n',abs(H),angle(H)*180/pi);
writetable(node_table,'Simulink_nodes_RMS.csv');
% Copy Real_V and Imag_V into the corresponding COMSOL terminal parameters.

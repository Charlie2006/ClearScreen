% Input charges_C.csv: numeric 5x6, no header.
% Columns: test_id,Q_n0,Q_n1,Q_n2,Q_n3,Q_n4; charges in coulomb.
% Rows correspond to voltage tests 0,1,2,3,4. Vtest was 1 volt.
raw=readmatrix('charges_C.csv');
assert(isequal(size(raw),[5 6]),'Expected 5 rows and 6 numeric columns.');
raw=sortrows(raw,1);
assert(isequal(raw(:,1),(0:4).'),'Expected test_id 0,1,2,3,4.');
assert(all(isfinite(raw(:))),'Input contains NaN or Inf.');
Vtest_V=1;
Cmaxwell=raw(:,2:6).'/Vtest_V; % transpose: each test supplies one column
writematrix(Cmaxwell,'stray_C_F.csv');
disp('Maxwell capacitance matrix, F:');disp(Cmaxwell);
disp('Use solve_50Hz_nodes.m to check the matrix and export branch values.');

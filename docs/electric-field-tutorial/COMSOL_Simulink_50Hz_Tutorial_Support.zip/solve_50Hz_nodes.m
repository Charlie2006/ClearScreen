% Five-node 50 Hz divider: analytical phasor reference, not a Simulink model.
% Node order: n0=HV, n1, n2, n3, n4=OUT; ground excluded from matrices.
% Optional input: stray_C_F.csv, numeric 5x5 Maxwell capacitance matrix in F.
% Include only external stray geometry here; nominal 200 pF remains in Cdesign.
clear; clc;
f0 = 50;
w = 2*pi*f0;
Rstage = 5e6;
Cstage = 200e-12;
Rlow = [40e3,20e3,10e3];
Clow = [25e-6,50e-6,100e-6];
Vin = [5e3,10e3,20e3]; % RMS, phase zero
node_names = ["n0";"n1";"n2";"n3";"n4"];
Cstray = zeros(5);
has_stray = isfile('stray_C_F.csv');
if has_stray
    Cstray = readmatrix('stray_C_F.csv');
    assert(isequal(size(Cstray),[5 5]),'Expected numeric 5-by-5 Maxwell matrix, units F.');
    assert(all(isfinite(Cstray(:))),'Matrix contains NaN or Inf.');
    scale = max(abs(Cstray(:)));
    assert(scale>0,'The supplied stray matrix is zero.');
    mismatch = norm(Cstray-Cstray.','fro')/norm(Cstray,'fro');
    fprintf('Maxwell matrix relative asymmetry: %.4g\n',mismatch);
    if mismatch>0.01
        error('Relative asymmetry exceeds 1%%. Inspect extraction before proceeding.');
    end
    offdiag = Cstray-diag(diag(Cstray));
    tol = 1e-6*scale;
    assert(all(diag(Cstray)>0),'Check diagonal values / charge sign.');
    assert(max(offdiag(:))<=tol,'Unexpected positive off-diagonal entry.');
    assert(min(sum(Cstray,2))>=-tol,'Unexpected negative ground branch.');
    % Export branch values, without silently converting negative values to abs.
    a = strings(0,1); b = strings(0,1); capacitance_F = zeros(0,1);
    for i=1:5
        a(end+1,1)=node_names(i); b(end+1,1)="g";
        capacitance_F(end+1,1)=sum(Cstray(i,:));
        for j=i+1:5
            a(end+1,1)=node_names(i); b(end+1,1)=node_names(j);
            capacitance_F(end+1,1)=-Cstray(i,j);
        end
    end
    branch_table=table(a,b,capacitance_F);
    writetable(branch_table,'stray_branches_F.csv');
else
    fprintf('No stray_C_F.csv: computing nominal circuit only.\n');
end
results = struct;
for gear=1:3
    G=zeros(5); Cdesign=zeros(5);
    for k=1:4
        e=zeros(5,1); e(k)=1; e(k+1)=-1;
        G=G+(e*e.')/Rstage;
        Cdesign=Cdesign+Cstage*(e*e.');
    end
    G(5,5)=G(5,5)+1/Rlow(gear);
    Cdesign(5,5)=Cdesign(5,5)+Clow(gear);
    Y0=G+1i*w*Cdesign;
    Yp=G+1i*w*(Cdesign+Cstray);
    V0=[Vin(gear); -(Y0(2:5,2:5)\Y0(2:5,1))*Vin(gear)];
    Vp=[Vin(gear); -(Yp(2:5,2:5)\Yp(2:5,1))*Vin(gear)];
    H0=V0(5)/V0(1); Hp=Vp(5)/Vp(1);
    fprintf('\n%d kV gear: nominal Vout=%.9g V RMS, phase=%.7f deg\n',...
        Vin(gear)/1000,abs(V0(5)),angle(H0)*180/pi);
    if has_stray
        fprintf('With stray: Vout=%.9g V RMS, magnitude change=%.7g%%, phase change=%.7g deg\n',...
            abs(Vp(5)),100*(abs(Hp)/abs(H0)-1),angle(Hp/H0)*180/pi);
    end
    node_table=table(node_names,real(Vp),imag(Vp),abs(Vp),angle(Vp)*180/pi,...
        'VariableNames',{'Node','Real_V','Imag_V','RMS_V','Phase_deg'});
    disp(node_table);
    writetable(node_table,sprintf('nodes_%dkV_RMS.csv',Vin(gear)/1000));
    results(gear).nominal_nodes=V0;
    results(gear).stray_nodes=Vp;
    results(gear).H0=H0; results(gear).Hp=Hp;
end
save('divider_50Hz_reference.mat','results','Cstray','f0','has_stray');
% Copy Real_V + i*Imag_V to COMSOL terminals for a phasor field solution.
